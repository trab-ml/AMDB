s'assurer d'avoir attribué tous les droits aux fichiers contenant des scripts permettant de manipuler les données de la database.

