document.addEventListener("DOMContentLoaded", () => {
    document.querySelector("#principal-title").style.opacity = "1";
});